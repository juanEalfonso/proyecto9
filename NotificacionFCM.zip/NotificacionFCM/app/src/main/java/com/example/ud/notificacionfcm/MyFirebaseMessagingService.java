package com.example.ud.notificacionfcm;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        if(remoteMessage.getData().size() > 0){
            Log.e("MFC : ",remoteMessage.getData().toString());
            Log.e("MFC :" ,remoteMessage.getData().get("MyTittle"));
            Log.e("MFC :" ,remoteMessage.getData().get("MyMessage"));
        }



        if(remoteMessage.getNotification() != null){
            Log.e("titulo : ",remoteMessage.getNotification().getTitle());
            Log.e("cuerpo :" ,remoteMessage.getNotification().getBody());
        }
    }
    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        Log.e("TITULO",s);
    }
}
